
package maze;

public interface UndoableCommand extends Command { 

  public void undo(); 

}
