
package maze.snow; 

import maze.*;

//don't forget to inherit
public class SnowWhiteMazeGameCreator  { 

	public Wall makeWall() { 
		  /* You need to replace this */
		  return null;	  
	  }

	  public Room makeRoom(int roomNumber) { 
		  /* You need to replace this */
		  return null;	  
	  }

	  public Door makeDoor(Room room1, Room room2) { 
		  /* You need to replace this */
		  return null;	  
	  }
}

