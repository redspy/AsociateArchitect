package oopreview.practice3;
public abstract class Canine extends Animal {
	protected boolean likeBones;
}
