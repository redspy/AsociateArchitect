package oopreview.practice3;

public abstract class Worker {
	public abstract void doWork();	
}
