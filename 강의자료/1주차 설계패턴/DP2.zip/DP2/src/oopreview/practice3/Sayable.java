package oopreview.practice3;
public interface Sayable {
	public void say();
}
