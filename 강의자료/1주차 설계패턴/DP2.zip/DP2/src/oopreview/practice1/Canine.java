package oopreview.practice1;
public abstract class Canine {
	protected boolean likeBones;
}
