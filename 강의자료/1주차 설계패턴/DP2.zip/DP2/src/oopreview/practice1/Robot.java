package oopreview.practice1;
public class Robot {	
	public void printOut() {
		System.out.println("I have no name. I am a Robot");
		System.out.println("Beep");
		System.out.println("------------------");
	}
}
