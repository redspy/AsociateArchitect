package oopreview.practice1;
public abstract class Animal {
	protected String name;	
}
