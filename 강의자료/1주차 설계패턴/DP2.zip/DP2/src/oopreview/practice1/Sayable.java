package oopreview.practice1;
public interface Sayable {
	public void say();
}
