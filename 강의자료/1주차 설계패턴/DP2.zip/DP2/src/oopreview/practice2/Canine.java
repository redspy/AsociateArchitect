package oopreview.practice2;
public abstract class Canine extends Animal {
	protected boolean likeBones;
}
