package oopreview.practice2;
public abstract class Animal {
	protected String name;
	abstract public void say();
}
