package delegationAnswer;
public interface Sayable {
	public void say();
}
