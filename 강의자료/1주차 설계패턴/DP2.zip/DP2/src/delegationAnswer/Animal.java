package delegationAnswer;

public abstract class Animal extends Worker {
	protected String name;
	abstract public void say();	
}
