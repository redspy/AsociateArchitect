package hiroshi.VisitorAnswer;
public interface Element {
    public abstract void accept(Visitor v);
}
