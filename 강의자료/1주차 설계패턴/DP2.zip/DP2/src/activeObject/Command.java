package activeObject;

public interface Command {
    public void execute();

}
