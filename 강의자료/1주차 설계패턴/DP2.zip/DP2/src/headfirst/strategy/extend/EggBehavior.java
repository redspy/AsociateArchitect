package headfirst.strategy.extend;

public interface EggBehavior {
	public void spawn();
}
