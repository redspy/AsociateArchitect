package headfirst.strategy.extend;

public interface FlyBehavior {
	public void fly();
}
