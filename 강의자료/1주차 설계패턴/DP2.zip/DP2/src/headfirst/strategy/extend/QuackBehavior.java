package headfirst.strategy.extend;

public interface QuackBehavior {
	public void quack();
}
