package headfirst.factory.pizzaaf.extended;

public interface Cheese {
	public String toString();
}
