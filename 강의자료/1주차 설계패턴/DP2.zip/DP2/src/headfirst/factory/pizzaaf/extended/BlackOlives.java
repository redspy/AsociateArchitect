package headfirst.factory.pizzaaf.extended;

public class BlackOlives implements Veggies {

	public String toString() {
		return "Black Olives";
	}
}
