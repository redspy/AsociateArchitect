package headfirst.factory.pizzaaf.extended;

public class SeoulPepperoni implements Pepperoni {

	public String toString() {
		return "Seoul Pepperoni";
	}
}
