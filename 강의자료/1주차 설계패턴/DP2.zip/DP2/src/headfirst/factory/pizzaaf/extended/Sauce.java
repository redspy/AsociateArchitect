package headfirst.factory.pizzaaf.extended;

public interface Sauce {
	public String toString();
}
