package headfirst.factory.pizzaaf.extended;

public class SeoulSpinach implements Veggies {

	public String toString() {
		return "Seoul Spinach";
	}
}
