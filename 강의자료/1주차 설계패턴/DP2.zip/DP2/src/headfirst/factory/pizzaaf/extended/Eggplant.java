package headfirst.factory.pizzaaf.extended;

public class Eggplant implements Veggies {

	public String toString() {
		return "Eggplant";
	}
}
