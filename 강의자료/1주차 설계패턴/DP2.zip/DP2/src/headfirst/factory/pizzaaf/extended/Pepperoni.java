package headfirst.factory.pizzaaf.extended;

public interface Pepperoni {
	public String toString();
}
