package headfirst.factory.pizzaaf.extended;

public interface Dough {
	public String toString();
}
