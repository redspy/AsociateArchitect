package headfirst.factory.pizzaaf.extended;

public class SeoulCheese implements Cheese {

	public String toString() {
		return "Seoul cheese";
	}
}
