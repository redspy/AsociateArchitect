package headfirst.factory.pizzaaf.extended;

public class SeoulClams implements Clams {

	public String toString() {
		return "Seoul Clams";
	}
}
