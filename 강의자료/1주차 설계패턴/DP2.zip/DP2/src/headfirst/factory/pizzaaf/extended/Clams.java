package headfirst.factory.pizzaaf.extended;

public interface Clams {
	public String toString();
}
