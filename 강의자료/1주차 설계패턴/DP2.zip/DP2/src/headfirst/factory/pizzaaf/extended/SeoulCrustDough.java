package headfirst.factory.pizzaaf.extended;

public class SeoulCrustDough implements Dough {
	public String toString() {
		return "Seoul style extra thick crust dough";
	}
}
