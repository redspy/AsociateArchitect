package headfirst.factory.pizzaaf.extended;

public class SeoulTomatoSauce implements Sauce {
	public String toString() {
		return "Seoul Tomato sauce";
	}
}
