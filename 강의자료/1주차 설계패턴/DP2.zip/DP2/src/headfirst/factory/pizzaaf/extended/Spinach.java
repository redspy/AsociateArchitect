package headfirst.factory.pizzaaf.extended;

public class Spinach implements Veggies {

	public String toString() {
		return "Spinach";
	}
}
