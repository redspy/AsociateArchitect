package headfirst.factory.pizzaaf.extended;

public interface Veggies {
	public String toString();
}
