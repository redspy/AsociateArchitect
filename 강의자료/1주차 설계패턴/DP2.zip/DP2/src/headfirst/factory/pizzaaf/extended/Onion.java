package headfirst.factory.pizzaaf.extended;

public class Onion implements Veggies {

	public String toString() {
		return "Onion";
	}
}
