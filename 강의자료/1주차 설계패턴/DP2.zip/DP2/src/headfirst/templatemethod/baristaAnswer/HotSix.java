package headfirst.templatemethod.baristaAnswer;

public class HotSix extends CaffeineBeverage {
	public void brew() {
		System.out.println("Poruing HotSix ingredients");
	}
	public void addCondiments() {
		System.out.println("Adding Much Sugar");
	}
}
