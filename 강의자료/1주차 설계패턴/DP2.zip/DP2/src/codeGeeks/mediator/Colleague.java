package codeGeeks.mediator;

public interface Colleague {
	
	public void setMediator(MachineMediator mediator);

}
