package codeGeeks.visitor;

public interface Element {
	
	public void accept(Visitor visitor);
}
