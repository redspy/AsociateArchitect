package delegationProblem;
public abstract class Canine extends Animal {
	protected boolean likeBones;
}
