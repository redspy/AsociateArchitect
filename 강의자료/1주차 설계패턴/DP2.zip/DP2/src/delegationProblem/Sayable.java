package delegationProblem;
public interface Sayable {
	public void say();
}
