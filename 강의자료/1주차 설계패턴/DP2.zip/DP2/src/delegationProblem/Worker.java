package delegationProblem;

public abstract class Worker {
	public abstract void doWork();	
}
